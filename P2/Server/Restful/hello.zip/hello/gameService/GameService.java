package com.restful.hello.gameService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;


@RestController
@RequestMapping("/api")
public class GameService {

    public static final Logger logger = LoggerFactory.getLogger(GameRepo.class);

    private GameRepo gameServise;
    private QRepo QServise;

    @RequestMapping(value = "/hello/", method = RequestMethod.GET)
    public String getHello() {
        return "Hello";
    }

    @RequestMapping(value ="/games/")
    public ResponseEntity<?> getAllGames() {
        logger.info("getting games");
        ArrayList<Game> games = new ArrayList<>();
        gameServise.findAll().forEach( games ::add );
        return new ResponseEntity<ArrayList<Game>>( games , HttpStatus.OK);
    }


    ///////////////////////////method///////////////////////
    @RequestMapping(value = "/game/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> getGame(@PathVariable String id) {
        logger.info("getting hello.user with id {}", id);
        Game game = gameServise.findOne(id);
        return new ResponseEntity<Game>(game, HttpStatus.OK);
    }

    ////////////////////////////////////////////////

@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value = "create/game/", method = RequestMethod.POST)
    public ResponseEntity<?> createGame(@RequestBody Game game ){
        logger.info("Creating Api_user : {}", game);
        logger.info(game.getTeacher() + " ID" );
        gameServise.save(game);
    ResponseEntity<String> responseEntity = new ResponseEntity<String>( game.getId() ,HttpStatus.OK);
        return responseEntity ;
    }

    @CrossOrigin(origins = "http://localhost:4200")
    @RequestMapping(value = "/add/q/{id}", method = RequestMethod.POST)
    public ResponseEntity<?> addQ(@RequestBody Q q , @PathVariable String id){
        logger.info("Creating Api_user : {}", q);
        logger.info( q.getQ() + " ID:" + id );
        Game game = gameServise.findOne( id );
        game.addQ(q);
        QServise.save(q);
        gameServise.save(game);

        ResponseEntity<?> responseEntity = new ResponseEntity<>(HttpStatus.OK);

        return responseEntity ;

    }

}
