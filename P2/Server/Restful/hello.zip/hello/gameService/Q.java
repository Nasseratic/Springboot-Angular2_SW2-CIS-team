package com.restful.hello.gameService;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;

/**
 * Created by LENOVO on 17/04/15.
 */

@Entity
public class Q {

    @Id
    @GeneratedValue
    String id ;
    String q ;
    String[] answers ;
    String ra ; //right answer
    @ManyToOne
    @JoinColumn
    Game game;

    public Q(String id, String q, String[] a, String ra, Game game) {
        this.id = id;
        this.q = q;
        this.answers = a;
        this.ra = ra;
        this.game = game;
    }

    public Q(String id, @JsonProperty("qus")String q , @JsonProperty("a")String[] a , @JsonProperty("ra")String ra) {
        this.id = id;
        this.q = q;
        this.answers = a;
        this.ra =ra;
    }

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }


    public Game getGame() {
        return game;
    }

    public void setGame(Game game) {
        this.game = game;
    }

    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setA(String[] a) {
        this.answers = a;

    }

    public String[] getA() {
        return answers;
    }
}
