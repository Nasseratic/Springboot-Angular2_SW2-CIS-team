package com.restful.hello.gameService;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Set;


@Component
@Entity
public class Game {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String id;
	@NotNull
	private String name;
	private String teacher;
	private String category;
	@OneToMany(mappedBy = "game" , cascade = CascadeType.ALL)
	private Set<Q> qs;
	public Game() {
	}

	public Game(String id, String name, String teacher, String category, Set<Q> qs) {
		this.id = id;
		this.name = name;
		this.teacher = teacher;
		this.category = category;
		this.qs = qs;
	}

	public void setQs(Set<Q> qs) {
		this.qs = qs;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeacher() {
		return teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	@JsonIgnore
	public Set<Q> getQs() {
		return qs;
	}

	@JsonIgnore
	public void addQ(Q q ) {

		this.qs.add(q);
	}

}
