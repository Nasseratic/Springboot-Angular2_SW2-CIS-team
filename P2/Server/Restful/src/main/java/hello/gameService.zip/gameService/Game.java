package hello.gameService;

import org.springframework.stereotype.Component;

import java.util.ArrayList;


@Component
public class Game {


	private String id;
	private String name;
	private String teacher;
	private String category;
	//private Q qs;
	public Game() {
		
	}

	public Game(String id, String name, String teacher, String category, Q qs) {
		this.id = id;
		this.name = name;
		this.teacher = teacher;
		this.category = category;
	//	this.qs = qs;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeacher() {
		return teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

//	public Q getQs() {
//		return qs;
//	}
//
//	public void setQs(Q qs) {
//		this.qs = qs;
//	}
}
