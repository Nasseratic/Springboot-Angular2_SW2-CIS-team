package hello.gameService;

import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class GameModel {
	

	ArrayList<Game> games = new ArrayList<>();

    public GameModel(){
      //  String[] as = { "fine","good","not good" };
       // this.games.add(new Game("0","first game","mhmeeaad@gmail.com","000", new Q("How are you ?", as  )));
    }


	public Game getUser(String name){
        for (int i = 0; i < games.size(); i++) {
            if(games.get(i).getName().equals(name))return games.get(i);
        }
        return null;
    }
	
	public void addGame(Game game){

        games.add(game);
	}

}
