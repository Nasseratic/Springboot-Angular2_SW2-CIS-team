package hello.gameService;

import java.util.ArrayList;

/**
 * Created by LENOVO on 17/04/15.
 */
public class Q {

    String q ;
    ArrayList<String> a ;

    public Q(String q, ArrayList<String> answers) {
        this.q = q;
        this.a = answers;
    }

    public String getQ() {
        return q;
    }

    public void setQ(String q) {
        this.q = q;
    }

    public ArrayList<String> getAnswers() {
        return a;
    }

    public void setAnswers(ArrayList<String> answers) {
        this.a = answers;
    }
}
