package hello.gameService;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;



@RestController
@RequestMapping("/")
public class GameService {

    public static final Logger logger = LoggerFactory.getLogger(GameModel.class);

    @Autowired
    private GameModel gameServise;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String getHello() {
        return "Hello";
    }

    /////////////////////////////////////////////method//
    @RequestMapping(value = "/game/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> getUser(@PathVariable String id) {
        logger.info("getting hello.user with id {}", id);
        Game user = gameServise.getUser(id);

        return new ResponseEntity<Game>(user, HttpStatus.OK);
    }

    ////////////////////////////////////////////////

//	 , UriComponentsBuilder ucBuilder
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(value = "/create/game/", method = RequestMethod.POST)
    public ResponseEntity<?> createGame(@RequestBody Game game){
        logger.info("Creating User : {}", game);
    //ObjectMapper mapper = new ObjectMapper();
    //JsonNode node = mapper.readTree(game);
    //Q  qs= mapper.convertValue(node.get("qs"), Q.class);
    //gameData gameData =mapper.convertValue(node.get("game"), gameData.class);
    //logger.info( "=>> " + qs.getQ());
   // Game theGame = new Game( gameData.getId(),gameData.getName(),gameData.getTeacher(),gameData.getCategory(),qs);
    //    gameServise.addGame(theGame);
    logger.info(game.getTeacher() + " ID:" + gameServise.games.size());
    ResponseEntity<String> responseEntity = new ResponseEntity<>("just response",
            HttpStatus.OK);
        return responseEntity ;
//
//	        HttpHeaders headers = new HttpHeaders();
//	        headers.setLocation(ucBuilder.path("/api/hello.user/{id}").buildAndExpand(user.getId()).toUri());
//	        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }
}

